package keyworddrivenframework0;

import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.sun.corba.se.impl.oa.poa.ActiveObjectMap.Key;

public class GetByObjectAndAct {

	WebDriver driver;
	OpenBrowser browserobj;

	public GetByObjectAndAct(WebDriver driver) {
		this.driver = driver;
	}

	public void performAction(String operation, String objectName,
			String objectType, String value) throws Exception {
		System.out.println("performing action");
		switch (operation.toUpperCase()) {

		case "CLICK":
			// Perform click
			driver.findElement(this.getByObject(objectName, objectType))
					.click();
			break;
			
		case "CLEAR":
			driver.findElement(this.getByObject(objectName, objectType)).clear();
			break;
			
			
		case "SETTEXT":
			// Set text on control
			driver.findElement(this.getByObject(objectName, objectType))
					.sendKeys(value);
			break;

			
			
			
		case "GOTOURL":
			// Get url of application
			driver.get(value);
			break;

		case "SELECT":
			Select dropDown = new Select(driver.findElement(this.getByObject(
					objectName, objectType)));
			List<WebElement> lst = dropDown.getOptions();
			int itemSize = lst.size();
			System.out.println(itemSize);
			for (int i = 0; i < itemSize; i++) {
				String optionsValue = lst.get(i).getText();
				System.out.println(optionsValue);
			}
			if (value.contains(".") == true) {
				value = value.split("\\.")[0];
			}
			dropDown.selectByVisibleText(value);

			break;

		case "GETTEXT":
			// Get text of an element
			String str = driver.findElement(
					this.getByObject(objectName, objectType)).getText();
			System.out.println(str);
			break;
		case "TIMEOUT":
			// Get url of application
			float sleeptime = Float.parseFloat(value);
			Thread.sleep((long) (sleeptime) * 1000);
			break;

			
		case "TAB":
			Actions actions = new Actions(driver);

			actions.sendKeys(Keys.TAB).build().perform();
			break;
			
		case "ENTER":
			Actions actions2 = new Actions(driver);

			actions2.sendKeys(Keys.ENTER).build().perform();
			break;

		case "DOWN":
			Actions actions3 = new Actions(driver);

			actions3.sendKeys(Keys.ARROW_DOWN).build().perform();
			break;
			
		default:
			break;
		}
	}

	/**
	 * Find element BY using object type and value * @param objectName
	 * 
	 * @param objectType
	 * @return
	 * @throws Exception
	 */
	private By getByObject(String objectName, String objectType)
			throws Exception {
		// Find by xpath
		if (objectType.equalsIgnoreCase("XPATH")) {

			return By.xpath(objectName);
		}
		// find by class
		else if (objectType.equalsIgnoreCase("CLASSNAME")) {

			return By.className(objectName);

		}
		// find by id
		else if (objectType.equalsIgnoreCase("ID")) {

			return By.id(objectName);

		}
		// find by name
		else if (objectType.equalsIgnoreCase("NAME")) {

			return By.name(objectName);

		}
		// Find by css
		else if (objectType.equalsIgnoreCase("CSS")) {

			return By.cssSelector(objectName);

		}
		// find by link
		else if (objectType.equalsIgnoreCase("LINK")) {

			return By.linkText(objectName);

		}
		// find by partial link
		else if (objectType.equalsIgnoreCase("PARTIALLINK")) {

			return By.partialLinkText(objectName);

		}

		else {
			throw new Exception("Wrong object type");
		}
	}
}